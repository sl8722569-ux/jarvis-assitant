#!/usr/bin/env python3
"""
J.A.R.V.I.S — Early Access / Phase 1 (stable desktop foundation)

Windows entrypoint. Shared logic lives in modules/ for future
Windows packaged app, Linux, web, and mobile adapters (see platform/).

Designed for modest hardware: Intel i3, 8GB RAM, HDD.
"""
from __future__ import annotations

import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from modules.ai_engine import AIEngine
from modules.ai_launcher import AILauncher
from modules.ai_providers import AIProviders
from modules.commands import CommandRouter
from modules.config_loader import Config
from modules.file_assistant import FileAssistant
from modules.language import is_exit_phrase, normalize_lang, phrase
from modules.logger import JarvisLogger
from modules.modes import ModeManager
from modules.optimizer import Optimizer
from modules.permissions import PermissionManager
from modules.share_assistant import ShareAssistant
from modules.state import JarvisState
from modules.stt_engine import STTEngine
from modules.system_ops import SystemOps
from modules.themes import get_theme
from modules.tts_engine import TTSEngine
from modules.ui import JarvisUI
from modules.web_ops import WebOps
from modules.share_project import share_jarvis
from modules.voice_diagnostics import (
    open_windows_mic_settings,
    run_full_diagnostics,
)
from modules.windows_assistant import WindowsAssistant
from modules.smart_assistant import SmartAssistant
from modules.plugins import PluginManager
from modules.plugins.builtin import load_builtin_plugins
from modules.language import is_standby_phrase


class Jarvis:
    def __init__(self):
        self.root = ROOT
        self.cfg = Config(self.root)
        self.log = JarvisLogger(self.root)
        self.log.info("J.A.R.V.I.S Phase 2 starting…")

        data_dir = self.root / "data"
        data_dir.mkdir(exist_ok=True)
        self.permissions = PermissionManager(data_dir, self.log)

        vcfg = self.cfg.get("voice") or {}
        feats = self.cfg.get("features") or {}
        lang_cfg = self.cfg.get("languages") or {}
        ui_cfg = self.cfg.get("ui") or {}
        primary = normalize_lang(lang_cfg.get("primary") or "en")
        pref_mode = (self.cfg.get("preferred_usage_mode") or ui_cfg.get("usage_mode") or "full")

        self.state = JarvisState(
            wake_word=bool(feats.get("wake_word", True)),
            hotkey=bool(feats.get("hotkey", True)),
            voice_listen=bool(feats.get("voice_listen", True)),
            voice_speak=bool(feats.get("voice_speak", True)),
            language=primary,
            personality=(self.cfg.get("personality_mode") or "friendly"),
            theme=ui_cfg.get("theme") or "midnight_hud",
            animation=ui_cfg.get("animation") or "hud",
            animations_enabled=bool(ui_cfg.get("animations_enabled", True)),
            voice_volume=float(vcfg.get("volume", 1.0)),
            voice_rate=int(vcfg.get("rate", 165)),
            room_boost=bool(vcfg.get("room_boost", True)),
            status_message="Standby — say Jarvis Activate",
            ui_state="standby",
            usage_mode=str(pref_mode),
            ui_layout=str(ui_cfg.get("layout") or "full"),
            performance_mode=bool(ui_cfg.get("performance_mode", False)),
            light_mode=bool(ui_cfg.get("light_mode", False)),
            preferred_mode_saved=bool(self.cfg.get("preferred_usage_mode")),
        )

        self.providers = AIProviders(self.cfg.data, self.permissions, self.log)
        self.ops = SystemOps(self.log)
        self.ai = AIEngine(self.cfg.data, self.log, providers=self.providers)
        self.modes = ModeManager(self.ops, self.log)
        self.optimizer = Optimizer(self.root, self.log)
        self.launcher = AILauncher(self.cfg.data, self.log)
        self.files = FileAssistant(self.permissions, self.log)
        self.share = ShareAssistant(self.permissions, self.log)
        self.web = WebOps(self.permissions, self.log)
        self.win = WindowsAssistant(self.root, self.log)
        self.smart = SmartAssistant()
        self.plugins = PluginManager()
        load_builtin_plugins(self.plugins)

        self.tts = TTSEngine(
            rate=int(vcfg.get("rate", 165)),
            volume=float(vcfg.get("volume", 1.0)),
            style=str(vcfg.get("style", "jarvis")),
            prefer_male=bool(vcfg.get("prefer_male", True)),
            room_boost=bool(vcfg.get("room_boost", True)),
            enabled=bool(feats.get("voice_speak", True)),
            log=self.log,
        )
        self.stt = STTEngine(self.cfg.data, self.log)
        self.stt.set_language(primary)

        self.stop = False
        self.session_lock = threading.Lock()
        self._listen_thread: threading.Thread | None = None
        self.conv_cfg = self.cfg.get("conversation") or {}
        self._awaiting_mode_choice = False

        self.router = CommandRouter(
            self.ops,
            self.ai,
            self.modes,
            self.optimizer,
            self.launcher,
            self.permissions,
            self.files,
            self.share,
            self.web,
            providers=self.providers,
            tts=self.tts,
            log=self.log,
            on_exit=self.standby,
            on_pause=self.pause_features,
            on_resume=self.resume_features,
            on_conversation=self.start_conversation_mode,
            on_theme=self.set_theme,
            set_ui_state=self.set_ui_state,
            win=self.win,
            smart=self.smart,
            plugins=self.plugins,
            on_usage_mode=self.set_usage_mode,
            on_layout=self.set_layout,
        )

        self.ui = JarvisUI(
            state=self.state,
            permissions=self.permissions,
            on_activate=self.activate,
            on_text=self.handle_text_command,
            on_voice_toggle=self.toggle_speak,
            on_pause=self.pause_features,
            on_resume=self.resume_features,
            on_stop_features=self.stop_features,
            on_open_ai=self.open_named_ai,
            on_volume=self.set_voice_volume,
            on_mic_listen=self.talk_or_continue,
            on_conversation=self.start_conversation_mode,
            on_standby=self.standby,
            on_theme=self.set_theme,
            on_personality=self.set_personality,
            on_animation=self.set_animation,
            on_permission_change=self.permission_change,
            on_save_settings=self.save_settings,
            on_share_project=self.share_project,
            on_voice_diagnostics=self.run_voice_diagnostics,
            on_mic_test=self.test_microphone,
            on_speaker_test=self.test_speaker,
            on_report_bug=self.report_bug,
        )
        # Let command router reach STT for voice tests
        self.router.stt = self.stt

    # ----- UI helpers -----
    def set_ui_state(self, mode: str) -> None:
        self.state.set_ui_state(mode)
        self.ui.set_ui_state(mode)

    def _sync_lang(self) -> None:
        self.state.language = self.ai.language
        self.stt.set_language(self.ai.language)

    def speak(self, text: str, chat: bool = True) -> None:
        if not text:
            return
        self.state.last_reply = text
        self.state.last_event = "speak"
        self._sync_lang()
        if chat:
            self.ui.append_jarvis(text)
        self.set_ui_state("speaking")
        if self.state.voice_speak and self.tts.enabled:
            ok = self.tts.speak(text, block=True)
            if not ok:
                # UI said Speaking but no audio — surface clear error + recover
                err = self.tts.last_error or "Unknown TTS failure"
                self.log.warn(f"TTS silent failure: {err}")
                self.ui.append_system(
                    f"Audio error: {err}. Trying recovery… Run 'speaker test' if it continues."
                )
                self.set_ui_state("error" if hasattr(self.state, "ui_state") else "standby")
                if self.tts.recover():
                    ok2 = self.tts.speak(text, block=True)
                    if not ok2:
                        self.ui.append_system(
                            "Still no audio. Check Windows volume / default speaker. "
                            "Text replies still work."
                        )
        if self.state.active:
            self.set_ui_state("listening" if self.state.conversation_mode else "standby")
        else:
            self.set_ui_state("standby")

    def run_voice_diagnostics(self) -> None:
        report = run_full_diagnostics(self.stt, self.tts, self.permissions)
        self.ui.append_system(report.as_text())
        self.log.event("voice_diagnostics", {"ok": report.ok, "mic": report.default_mic_name})
        # Rebind STT to recommended mic if needed
        if report.default_mic_index is not None and self.stt.device_index != report.default_mic_index:
            self.stt.device_index = report.default_mic_index
            self.stt.recover()
            self.ui.append_system(f"STT rebound to mic [{report.default_mic_index}] {report.default_mic_name}")

    def test_microphone(self) -> None:
        if not self.permissions.is_allowed("microphone"):
            self.ui.append_system(
                "Microphone permission DENIED. Enable it in Settings → Permissions, "
                "and allow desktop apps in Windows Privacy → Microphone."
            )
            return
        msg = self.stt.test_microphone(2.0)
        self.ui.append_system(msg)
        self.log.event("mic_test", {"msg": msg[:120]})

    def test_speaker(self) -> None:
        self.set_ui_state("speaking")
        msg = self.tts.test_speaker()
        self.ui.append_system(msg)
        self.set_ui_state("standby")
        self.log.event("speaker_test", {"msg": msg[:120], "method": self.tts.last_method})

    def set_voice_volume(self, volume: float) -> None:
        self.tts.set_volume(volume)
        self.state.voice_volume = self.tts.volume
        try:
            self.cfg.data.setdefault("voice", {})["volume"] = self.tts.volume
            self.cfg.save()
        except Exception:
            pass

    def toggle_speak(self) -> None:
        self.state.voice_speak = not self.state.voice_speak
        self.tts.set_enabled(self.state.voice_speak)
        self.ui.append_system(f"Voice output {'ON' if self.state.voice_speak else 'OFF'}.")

    def open_named_ai(self, name: str) -> None:
        self.speak(self.launcher.launch(name))

    def set_theme(self, name: str) -> None:
        self.state.theme = name
        th = get_theme(name)
        self.state.animation = th.get("effect") or self.state.animation
        self.ui.apply_theme(name)
        self.cfg.data.setdefault("ui", {})["theme"] = name
        self.cfg.data["ui"]["animation"] = self.state.animation
        self.cfg.save()
        self.log.event("theme", {"name": name})

    def set_personality(self, mode: str) -> None:
        msg = self.ai.set_personality(mode)
        self.state.personality = self.ai.personality.mode
        self.cfg.data["personality_mode"] = self.state.personality
        self.cfg.save()
        self.ui.append_system(msg)
        self.speak(msg)

    def set_animation(self, name: str) -> None:
        self.state.animation = name
        self.cfg.data.setdefault("ui", {})["animation"] = name
        self.cfg.save()
        self.ui.append_system(f"Animation: {name}")

    def permission_change(self, key: str, value: bool) -> None:
        if key == "__all__":
            self.permissions.revoke_all()
            self.ui.append_system("All permissions revoked.")
            return
        if value:
            self.ui.append_system(self.permissions.grant(key))
        else:
            self.ui.append_system(self.permissions.revoke(key))

    def save_settings(self) -> None:
        self.cfg.data["personality_mode"] = self.state.personality
        self.cfg.data["preferred_usage_mode"] = self.state.usage_mode
        ui = self.cfg.data.setdefault("ui", {})
        ui["theme"] = self.state.theme
        ui["animation"] = self.state.animation
        ui["animations_enabled"] = self.state.animations_enabled
        ui["layout"] = self.state.ui_layout
        ui["usage_mode"] = self.state.usage_mode
        ui["performance_mode"] = self.state.performance_mode
        ui["light_mode"] = self.state.light_mode
        self.cfg.save()
        self.permissions.save()
        self.ui.append_system("Settings saved.")

    def set_usage_mode(self, mode: str) -> str:
        mode = (mode or "full").lower().strip()
        if mode not in ("full", "sidebar", "voice_only"):
            return "Choose: full, sidebar, or voice_only."
        self.state.usage_mode = mode
        self.state.preferred_mode_saved = True
        self.cfg.data["preferred_usage_mode"] = mode
        self.cfg.data.setdefault("ui", {})["usage_mode"] = mode
        self.cfg.save()
        self._awaiting_mode_choice = False
        if mode == "full":
            self.set_layout("full")
            msg = "Full Jarvis Mode saved. Window + voice + chat."
        elif mode == "sidebar":
            self.set_layout("sidebar")
            msg = "Sidebar Companion Mode saved. Compact side panel."
        else:
            self.set_layout("compact")
            msg = "Voice Only Mode saved. Minimal UI, voice focused."
        self.ui.append_system(msg)
        return msg

    def set_layout(self, layout: str) -> str:
        layout = (layout or "full").lower().strip()
        if layout not in ("full", "floating", "sidebar", "compact"):
            return "Layouts: full, floating, sidebar, compact."
        self.state.ui_layout = layout
        self.cfg.data.setdefault("ui", {})["layout"] = layout
        if layout == "compact" or self.state.performance_mode:
            self.state.animations_enabled = False
        self.cfg.save()
        try:
            self.ui.apply_layout(layout)
        except Exception:
            pass
        return f"Layout: {layout}."

    def share_project(self, method: str = "copy") -> None:
        """Settings → Share Jarvis: public project link only (no private data)."""
        msg = share_jarvis(self.cfg.data, method=method or "copy")
        self.ui.append_system(msg)
        self.log.event("share_project", {"method": method or "copy", "private_data": False})

    def report_bug(self, text: str) -> None:
        """Save bug/glitch report locally (never uploads private data automatically)."""
        from datetime import datetime

        bugs = self.root / "data" / "bug_reports"
        bugs.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = bugs / f"bug_{stamp}.txt"
        body = (
            f"J.A.R.V.I.S bug report\n"
            f"Phase 1 [EARLY ACCESS] · Phase 2 [EARLY ACCESS FINAL ACT]\n"
            f"Time: {datetime.now().isoformat(timespec='seconds')}\n"
            f"Version: {self.cfg.get('version')}\n"
            f"Report:\n{text}\n"
        )
        path.write_text(body, encoding="utf-8")
        self.ui.append_system(f"Bug report saved locally: {path.name} (not shared online).")
        self.log.event("bug_report", {"file": path.name})

    # ----- lifecycle -----
    def activate(self) -> None:
        if self.state.paused:
            self.resume_features()
        on_act = self.cfg.get("on_activate") or {}
        self.state.active = True
        self.state.conversation_mode = bool(self.conv_cfg.get("followup_after_activate", True))
        self.state.status_message = "Online"
        self.state.set_task("ai_session", True)
        self.set_ui_state("thinking")

        # Apply preferred usage mode layout
        if self.state.usage_mode == "sidebar":
            self.set_layout("sidebar")
        elif self.state.usage_mode == "voice_only":
            self.set_layout("compact")
        else:
            self.set_layout(self.state.ui_layout or "full")

        if on_act.get("open_app_window", True) and self.state.usage_mode != "voice_only":
            self.ui.show_window(True)
            self.ui.set_active(True)
        elif self.state.usage_mode == "voice_only":
            self.ui.show_window(True)
            self.ui.set_active(True)
            try:
                self.ui.apply_layout("compact")
            except Exception:
                pass

        if on_act.get("open_web_ai", False):
            threading.Thread(
                target=self.launcher.launch,
                args=(on_act.get("web_ai_provider") or "chatgpt",),
                daemon=True,
            ).start()

        greet = self.ai.personality.greeting(self.ai.language)
        if self.ai.language == "en" and self.cfg.get("greeting"):
            if self.ai.personality.mode == "friendly":
                greet = self.cfg.get("greeting") or greet

        self.log.event("activate", {"mode": self.state.usage_mode})
        if on_act.get("speak_greeting", True):
            self.speak(greet)
        else:
            self.ui.append_jarvis(greet)

        # Phase 2: ask how to use Jarvis unless preferred mode already saved
        if not self.state.preferred_mode_saved:
            ask = (
                "How would you like to use Jarvis? "
                "Say Full Jarvis Mode, Sidebar Companion Mode, or Voice Only Mode."
            )
            self._awaiting_mode_choice = True
            self.speak(ask)
        else:
            self.ui.append_system(f"Using preferred mode: {self.state.usage_mode}")

        if on_act.get("start_listening", True) and self.state.voice_listen:
            if self.permissions.is_allowed("microphone"):
                self._start_listen_loop(conversation=True)
            else:
                self.ui.append_system(
                    "Voice follow-ups need microphone permission (Settings → Permissions)."
                )

    def start_conversation_mode(self) -> None:
        if self.state.paused:
            self.resume_features()
        if not self.permissions.is_allowed("microphone"):
            # Still allow text conversation
            self.ui.append_system(
                "Conversation (text) on. Allow microphone in Settings for voice turns."
            )
        self.state.active = True
        self.state.conversation_mode = True
        self.state.status_message = "Conversation mode"
        self.state.set_task("ai_session", True)
        self.state.set_task("conversation", True)
        self.ui.show_window(True)
        self.ui.set_active(True)
        msg = phrase("conversation_on", self.ai.language)
        self.speak(msg)
        self.log.event("conversation_on", {})
        if self.permissions.is_allowed("microphone") and self.state.voice_listen:
            self._start_listen_loop(conversation=True)

    def standby(self) -> None:
        self.state.active = False
        self.state.conversation_mode = False
        self.state.status_message = "Standby — say Jarvis Activate"
        self.state.set_task("ai_session", False)
        self.state.set_task("listening", False)
        self.state.set_task("conversation", False)
        self.set_ui_state("standby")
        msg = phrase("conversation_off", self.ai.language)
        self.ui.set_active(False, msg)
        if self.state.voice_speak:
            self.tts.speak(msg, block=False)
        self.log.event("standby", {})

    def deactivate(self) -> None:
        self.standby()

    def pause_features(self) -> None:
        self.state.paused = True
        self.state.active = False
        self.state.conversation_mode = False
        self.state.wake_word = False
        self.state.voice_listen = False
        self.state.status_message = "Paused"
        self.state.set_task("listening", False)
        self.state.set_task("wake_word", False)
        self.state.set_task("conversation", False)
        self.set_ui_state("standby")
        self.ui.append_system("Paused background listening. Text chat still works.")

    def resume_features(self) -> None:
        feats = self.cfg.get("features") or {}
        self.state.paused = False
        self.state.wake_word = bool(feats.get("wake_word", True))
        self.state.hotkey = bool(feats.get("hotkey", True))
        self.state.voice_listen = bool(feats.get("voice_listen", True))
        self.state.voice_speak = bool(feats.get("voice_speak", True))
        self.tts.set_enabled(self.state.voice_speak)
        self.state.status_message = "Resumed"
        self.state.set_task("wake_word", self.state.wake_word)
        self.ui.append_system("Features resumed.")

    def stop_features(self) -> None:
        self.state.paused = True
        self.state.active = False
        self.state.conversation_mode = False
        self.state.wake_word = False
        self.state.hotkey = False
        self.state.voice_listen = False
        for t in ("listening", "wake_word", "hotkey", "conversation"):
            self.state.set_task(t, False)
        self.state.status_message = "Features stopped"
        self.set_ui_state("standby")
        self.ui.set_active(False, "Low resource mode — listening stopped.")

    # ----- input -----
    def handle_text_command(self, text: str) -> None:
        low = (text or "").lower().strip()
        phrases = [p.lower() for p in self.cfg.get("activation_aliases", [])]
        if any(p in low for p in phrases) or low in ("activate", "jarvis"):
            self.activate()
            return
        if is_standby_phrase(text) or is_exit_phrase(text):
            self.standby()
            return
        if any(
            x in low
            for x in (
                "conversation mode",
                "start conversation",
                "talk to me",
                "let's talk",
                "lets talk",
            )
        ):
            self.start_conversation_mode()
            return

        # Mode choice after activation
        if self._awaiting_mode_choice:
            if "sidebar" in low:
                self.speak(self.set_usage_mode("sidebar"))
                return
            if "voice" in low:
                self.speak(self.set_usage_mode("voice_only"))
                return
            if "full" in low:
                self.speak(self.set_usage_mode("full"))
                return

        if not self.state.active and not self.state.paused:
            self.state.active = True
            self.state.conversation_mode = True
            self.ui.show_window(True)
            self.ui.set_active(True)
            self.state.set_task("conversation", True)

        self.state.last_heard = text
        self.ai.maybe_update_language(text)
        self._sync_lang()
        self.set_ui_state("thinking")
        reply = self.router.handle(text)
        if reply:
            self.speak(reply)

    def talk_or_continue(self) -> None:
        ok, msg = self.permissions.require("microphone")
        if not ok:
            self.ui.append_system(msg)
            return
        if not self.stt.available:
            self.ui.append_system("Microphone hardware/STT not available.")
            return
        if not self.state.conversation_mode and not self.state.active:
            self.start_conversation_mode()
            return
        if self._listen_thread and self._listen_thread.is_alive():
            self.ui.append_system(phrase("listening", self.ai.language))
            return
        self._start_listen_loop(conversation=True)

    def _start_listen_loop(self, conversation: bool) -> None:
        if self._listen_thread and self._listen_thread.is_alive():
            return
        if not self.permissions.is_allowed("microphone"):
            return
        self._listen_thread = threading.Thread(
            target=self._conversation_loop if conversation else self._short_listen_loop,
            daemon=True,
        )
        self._listen_thread.start()

    def _short_listen_loop(self) -> None:
        max_idle = int(self.conv_cfg.get("activate_idle_turns", 4))
        self._run_turns(max_idle=max_idle, keep_conversation_flag=False)

    def _conversation_loop(self) -> None:
        max_idle = int(self.conv_cfg.get("conversation_idle_turns", 8))
        self._run_turns(max_idle=max_idle, keep_conversation_flag=True)

    def _run_turns(self, max_idle: int, keep_conversation_flag: bool) -> None:
        with self.session_lock:
            idle = 0
            self.state.set_task("listening", True)
            while self.state.active and not self.stop and not self.state.paused and idle < max_idle:
                if keep_conversation_flag and not self.state.conversation_mode:
                    break
                if not self.state.voice_listen or not self.stt.available:
                    break
                if not self.permissions.is_allowed("microphone"):
                    break

                self.set_ui_state("listening")
                self.ui.append_system(phrase("listening", self.ai.language))
                self.stt.set_language(self.ai.language)
                heard = self.stt.listen_once(timeout=7, language=self.ai.language)
                if not heard:
                    idle += 1
                    if idle == max(2, max_idle // 2) and keep_conversation_flag:
                        self.speak(phrase("follow_up", self.ai.language))
                    continue

                idle = 0
                self.ui.append_user(heard)
                self.state.last_heard = heard
                self.ai.maybe_update_language(heard)
                self._sync_lang()

                if is_exit_phrase(heard):
                    self.speak(phrase("conversation_off", self.ai.language))
                    self.standby()
                    break

                self.set_ui_state("thinking")
                reply = self.router.handle(heard)
                if reply:
                    self.speak(reply)

            self.state.set_task("listening", False)
            if self.state.active and idle >= max_idle:
                self.speak(phrase("conversation_off", self.ai.language))
                self.standby()

    def wake_word_loop(self) -> None:
        phrases = [p.lower() for p in self.cfg.get("activation_aliases", ["jarvis activate"])]
        self.state.set_task("wake_word", True)
        while not self.stop:
            if self.state.paused or not self.state.wake_word or self.state.active:
                time.sleep(0.6)
                continue
            # Respect Windows + app permission — never listen without grant
            if not self.permissions.is_allowed("microphone"):
                time.sleep(2.0)
                continue
            if not self.state.voice_listen:
                time.sleep(2.0)
                continue
            if not self.stt.available:
                self.stt.recover()
                time.sleep(2.0)
                continue
            text = self.stt.listen_once(timeout=2.5, language="en")
            if not text:
                time.sleep(float(self.cfg.get("idle_sleep_sec", 0.5)))
                continue
            if self.stt.matches_wake_phrase(text, phrases):
                self.log.info(f"Wake: {text}")
                low = text.lower()
                if "conversation" in low or "talk" in low:
                    self.start_conversation_mode()
                else:
                    self.activate()

    def hotkey_loop(self) -> None:
        try:
            import ctypes

            user32 = ctypes.windll.user32
            was = False
            self.state.set_task("hotkey", True)
            while not self.stop:
                if self.state.paused or not self.state.hotkey:
                    time.sleep(0.4)
                    continue
                down = bool(
                    (user32.GetAsyncKeyState(0x11) & 0x8000)
                    and (user32.GetAsyncKeyState(0x10) & 0x8000)
                    and (user32.GetAsyncKeyState(0x4A) & 0x8000)
                )
                if down and not was:
                    self.activate()
                was = down
                time.sleep(0.15)
        except Exception as e:
            self.log.warn(f"Hotkey unavailable: {e}")

    def run(self) -> None:
        self.log.info("JARVIS v3 online.")
        try:
            self.optimizer.analyze()
        except Exception:
            pass
        self.ui.start()
        time.sleep(0.8)
        self.ui.append_system(
            "J.A.R.V.I.S [EARLY ACCESS] · Phase 2\n"
            "Permissions default OFF — enable Microphone in Settings for voice.\n"
            "Voice tools: Voice Diagnostics · Mic test · Speaker test\n"
            f"Theme: {self.state.theme} · Personality: {self.state.personality}\n"
            f"Mic: [{self.stt.device_index}] {self.stt.device_name or 'detecting…'}"
        )
        threading.Thread(target=self.wake_word_loop, daemon=True).start()
        threading.Thread(target=self.hotkey_loop, daemon=True).start()
        try:
            while not self.stop:
                time.sleep(1.0)
        except KeyboardInterrupt:
            self.stop = True


def main() -> None:
    Jarvis().run()


if __name__ == "__main__":
    main()
